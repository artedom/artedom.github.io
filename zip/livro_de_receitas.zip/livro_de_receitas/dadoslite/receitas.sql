BEGIN TRANSACTION;
CREATE TABLE `menu` (
	`codigo`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	`nome`	TEXT NOT NULL,
	`ingrediente`	TEXT NOT NULL,
	`preparo`	TEXT NOT NULL,
	`dicas`	TEXT
);
INSERT INTO `menu` VALUES(1,'Broa de milho de padaria','250g de farinha de trigo, 250g de fuba, 250g de açucar, 1 colher de chá de erva doce, 2 und. de ovos, 3 colheres de sopa de leite, 125g de manteiga, 1 colher de sopa de fermento quimico.','1- misture os ingredientes secos, 2- coloque a margarina e misture fazendo uma farofa, 3- acrescente os ovos, em seguida o leite, 4- deixar no ponto de enrrolar nas mãos, 5- a massa não pode ficar amolecida, é no ponto durinha, 6- faça bolinhas e achate, 7- asse por uns 25 minutos ao menos, deixe espaço para a massa crescer.','obeservar quando estiver dourada.');
COMMIT;
